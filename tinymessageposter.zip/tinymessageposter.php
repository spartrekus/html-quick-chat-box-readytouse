<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  



 <h2> HTML/PHP - TINY MESSAGE POSTER </h2>
  
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Message: <textarea name="mymessage" rows="5" cols="40"><?php echo $mymessage;?></textarea>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>

<?php
// echo "<h2>Your Input:</h2>";
echo "<br>";
echo $mymessage;
?>



<?php    
/// do not forget to make the txt file, to make it work
$now = time();
$num = date("w");
if ($num == 0)
{ $sub = 6; }
else { $sub = ($num-1); }
$WeekMon  = mktime(0, 0, 0, date("m", $now)  , date("d", $now)-$sub, date("Y", $now));    //monday week begin calculation
$todayh = getdate($WeekMon); //monday week begin reconvert

$dd = $todayh[mday];
$mm = $todayh[mon];
$yy = $todayh[year];
$timenow = date("Ymd-His-w"); 

if(isset($_POST['submit'])){ 
$input = $_POST['mymessage']; //get input text
echo "|IM Sent!| You entered: ".$input . "<br>" ;
echo '<br><br>' ;
$txt = "";
$myfile = fopen("messages.txt", "ab+") or die("Unable to open file!");
fwrite($myfile, $timenow );
fwrite($myfile, " ; ");
$txt = $input ;
fwrite($myfile, $txt);
fwrite($myfile, "\n");
fclose($myfile);
}    
?>


<br/>
<br/>
<h2>message List:</h2>
<hr/>

<table style="width: 95%">
    <tr>
        <td><b>Title</b></td>
        <td><b>Info (#1)</b></td>
        <td><b>Info (#2)</b></td>
        <td><b>Info (#3)</b></td>
        <td><b>Info (#4)</b></td>
    </tr>

<?php
$file = fopen("messages.txt", "r");
while(! feof($file))
{
   $item = fgets($file);
   list($field1,$field2,$field3,$field4) = explode( ";", $item ) ; 
        echo " <tr> "; 
        echo '<td>'; echo " " . $field2 . " "; echo "</td>";
        echo "<td>"; echo " " . $field3 . " "; echo "</td>";
        echo "<td>"; echo " " . $field4 . " "; echo "</td>";
        echo "</tr>";
}
fclose($file);
?>
</table>
<hr/>



<br/><br/>
|HTML/PHP - TINY MESSAGE POSTER| <br>
|Found On Spartrekus (GNU)| <br>
</body>
</html>



